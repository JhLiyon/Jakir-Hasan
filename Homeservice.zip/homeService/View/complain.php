<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Complain</title>
</head>
<style>
    body {
        display: flex;
        justify-content: center;
        align-items: center;
    }


    label {
        display: block;
        margin-bottom: 8px;
    }

    input,
    textarea {
        width: 100%;
        padding: 12px 20px;
        margin: 8px 0;
    }

    ul {
        list-style-type: none;
        overflow: hidden;
        background-color: white;


    }

    li {
        float: left;
        margin: 20px;

    }
</style>

<body>
    <div>
        <ul style="display:inline-block">
            <li><a href="order.php">Order</a></li>
            <li><a href="orderTable.php">Order History</a></li>
            <li><a href="complain.php">Complain</a></li>
            <li><a href="complainHistory.php">Complain History</a></li>
            <li><a href="login.php">Logout</a></li>
        </ul>
        <h2>Complain from</h2>
        <form action="../Controller/complainController.php" method="post">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name">

            <label for="email">Email:</label>
            <input type="email" id="email" name="email">

            <label for="phoneNo">Phone Number:</label>
            <input type="text" id="phoneNo" name="phoneNo">

            <label for="message">Message:</label>
            <textarea id="message" name="message"></textarea>

            <button name="submit" type="submit" onclick="validateForm()">Submit</button>
        </form>
    </div>
</body>

</html>

<script>
    function validateForm() {
        var name = document.getElementById('name').value;
        var email = document.getElementById('email').value;
        var phoneNo = document.getElementById('phoneNo').value;
        var message = document.getElementById('message').value;
        if (name == '' || email == '' || phoneNo == '' || message == '') {
            alert('Please fill in all the required fields.');
            event.preventDefault();
        }

    }
</script>