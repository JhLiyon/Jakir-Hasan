<!DOCTYPE html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order History</title>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
        }

        table {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        ul {
            list-style-type: none;
            overflow: hidden;
            background-color: white;


        }

        li {
            float: left;
            margin: 20px;

        }
    </style>
</head>

<body>
    <div>
        <ul style="display:inline-block">
            <li><a href="order.php">Order</a></li>
            <li><a href="orderTable.php">Order History</a></li>
            <li><a href="complain.php">Complain</a></li>
            <li><a href="complainHistory.php">Complain History</a></li>
            <li><a href="login.php">Logout</a></li>
        </ul>

        <?php
        require('../Controller/complainHistoryController.php');
        if (!empty($orderData)) {
            echo "<table>
                <tr>
                <th>Name</th>
                <th>Email</th>
                <th>phone Number</th>
                <th>message</th>
                <th>complain Date</th>
                
            </tr>";

            foreach ($orderData as $row) {
                echo "<tr>
                <td>{$row['name']}</td>
                <td>{$row['email']}</td>
                <td>{$row['phoneNo']}</td>
                <td>{$row['message']}</td>
                <td>{$row['created_date']}</td>
              </tr>";
            }

            echo "</table>";
        }
        ?>

    </div>

</body>

</html>