<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Form</title>
</head>
<style>
    body {
        display: flex;
        justify-content: center;
        align-items: center;
    }


    label {
        display: block;
        margin-bottom: 8px;
    }

    input,
    textarea {
        width: 100%;
        padding: 12px 20px;
        margin: 8px 0;
    }

    ul {
        list-style-type: none;
        overflow: hidden;
        background-color: white;


    }

    li {
        float: left;
        margin: 20px;

    }
</style>

<body>
    <div>
        <ul style="display:inline-block">
            <li><a href="order.php">Order</a></li>
            <li><a href="orderTable.php">Order History</a></li>
            <li><a href="complain.php">Complain</a></li>
            <li><a href="complainHistory.php">Complain History</a></li>
            <li><a href="login.php">Logout</a></li>
        </ul>
        <h2>Order Form</h2>
        <form id="orderForm" action="../Controller/orderController.php" method="post">
            <label for="customer_name">Customer Name:</label>
            <input type="text" id="customer_name" name="customer_name">

            <label for="customer_phoneNo">Customer Phone Number:</label>
            <input type="number" id="customer_phoneNo" name="customer_phoneNo">

            <label for="customer_address">Customer Address:</label>
            <textarea id="customer_address" name="customer_address"></textarea>

            <label for="order_schedule">Order Schedule:</label>
            <input type="date" id="order_schedule" name="order_schedule">

            <label for="service_id">Service Name:</label>
            <input type="text" id="service_id" name="service_name">

            <br>

            <button style="background-color:blue;width:100px;color:white;margin-top:10px;height:20px" type="submit"
                name="submit" onclick="validateForm()">Submit Order</button>
        </form>
    </div>
</body>

</html>

<script>
    function validateForm() {
        var customerName = document.getElementById('customer_name').value;
        var customerPhone = document.getElementById('customer_phoneNo').value;
        var customerAddress = document.getElementById('customer_address').value;
        var orderSchedule = document.getElementById('order_schedule').value;
        var serviceId = document.getElementById('service_id').value;

        if (customerName == '' || customerPhone == '' || customerAddress == '' ||
            orderSchedule == '' ||
            serviceId == '') {
            alert('Please fill in all the required fields.');
            event.preventDefault();
        }
    }
</script>