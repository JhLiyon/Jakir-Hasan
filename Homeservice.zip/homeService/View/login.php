<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<style>
    body {
        background-image: url(login.jpg);
        background-size: cover;
    }

    label {
        display: block;
        margin-bottom: 8px;
        color: black
    }
</style>

<body>
    <div style="width:100%;display:flex;justify-content:center;margin-top:200px">
        <div style="color:red;font-Size:40px;">
            <h1>Home Service</h1>
        </div>
        <div style="margin-left:400px;background-color:#FEDC5B;padding:20px">
            <h2 style="color:red">Login with Email & Password</h2>
            <form id="loginForm" action="../Controller/loginController.php" method="post">
                <label for="email">Email:</label>
                <input type="text" id="email" name="email">

                <label for="password">Password:</label>
                <input type="password" id="password" name="password">
                <br>
                <button style="background-color:blue;width:100px;color:white;margin-top:10px;height:20px" name="submit"
                    type="submit" onclick="validateForm()">Login</button>
            </form>
        </div>
    </div>


</body>

</html>

<script>
    function validateForm() {
        var email = document.getElementById('email').value;
        var password = document.getElementById('password').value;
        if (email === '' || password === '') {
            alert('Email and password are required');
            event.preventDefault();
        }
    }
</script>