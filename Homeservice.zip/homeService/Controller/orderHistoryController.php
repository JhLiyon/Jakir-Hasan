<?php
require('../Model/orderModel.php');
$orderData = GetAllOrder();

?>