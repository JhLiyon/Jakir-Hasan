<?php
require('../Model/orderModel.php');
$error = '';
if (isset($_POST['submit'])) {
    $customer_name = $_POST['customer_name'];
    $customer_phoneNo = $_POST['customer_phoneNo'];
    $customer_address = $_POST['customer_address'];
    echo $customer_address;
    $order_date = date('Y-m-d');
    $order_schedule = $_POST['order_schedule'];
    $service_name = $_POST['service_name'];
    $customer_id = 1;
    $result = orderInsert($customer_id, $customer_name, $customer_phoneNo, $customer_address, $order_date, $order_schedule, $service_name);
    if ($result) {
        header('Location: ../View/orderTable.php');
    } else {
        $error = 'Insert failed';
        header('Location: ../View/order.php');
    }
}
?>