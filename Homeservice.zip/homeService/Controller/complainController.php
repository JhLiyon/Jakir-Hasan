<?php
require('../Model/complainModel.php');
$error = '';
if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phoneNo = $_POST['phoneNo'];
    $message = $_POST['message'];
    $createdDate = date('Y-m-d H:i:s');
    $result = complain($name, $email, $phoneNo, $message, $createdDate);
    if ($result) {
        header('Location: ../View/complain.php');
    } else {
        $error = 'Insert failed';
        header('Location: ../View/complain.php');
    }
}
?>