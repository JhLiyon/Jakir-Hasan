<?php
require('../Model/loginModel.php');
$error = '';
if (isset($_POST['submit'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $result = Login($email, $password);
    if ($result != null) {
        header('Location: ../View/order.php');
    } else {
        header('Location: ../View/login.php');
    }
}
?>