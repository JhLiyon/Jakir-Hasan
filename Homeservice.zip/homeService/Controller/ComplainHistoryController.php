<?php
require('../Model/complainModel.php');
$orderData = GetAllComplain();

?>