<?php

function orderInsert($customer_id, $customer_name, $customer_phoneNo, $customer_address, $order_date, $order_schedule, $service_name)
{
    $con = mysqli_connect('localhost', 'root', '', 'homeservice');
    $sql = "INSERT INTO orders (customer_id,customer_name, customer_phoneNo, customer_address, order_date, order_schedule, service_name) 
    VALUES ('$customer_id','$customer_name', '$customer_phoneNo', '$customer_address', '$order_date', '$order_schedule', '$service_name')";

    if (mysqli_query($con, $sql)) {
        return true;
    } else {
        return false;
    }
}

function GetAllOrder()
{
    $con = mysqli_connect('localhost', 'root', '', 'homeservice');
    $sql = "SELECT *FROM orders";
    $result = $con->query($sql);
    $orderData = array();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $orderData[] = $row;
        }
    }
    return $orderData;
}
?>