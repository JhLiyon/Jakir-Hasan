<?php

function complain($name, $email, $phoneNo, $message, $createdDate)
{
    $con = mysqli_connect('localhost', 'root', '', 'homeservice');
    $sql = "INSERT INTO helpmails  (name, email, phoneNo, message, created_date) 
    VALUES ('$name', '$email', '$phoneNo', '$message', '$createdDate')";

    if (mysqli_query($con, $sql)) {
        return true;
    } else {
        return false;
    }
}

function GetAllComplain()
{
    $con = mysqli_connect('localhost', 'root', '', 'homeservice');
    $sql = "SELECT *FROM helpmails";
    $result = $con->query($sql);
    $orderData = array();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $orderData[] = $row;
        }
    }
    return $orderData;
}
?>