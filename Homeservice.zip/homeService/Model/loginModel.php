<?php

function login($email, $password)
{
    $con = mysqli_connect('localhost', 'root', '', 'homeservice');
    $sql = "SELECT * FROM `users` WHERE `email`='$email' AND `password`='$password'";
    $result = $con->query($sql);

    if ($result->num_rows == 1) {
        $row = mysqli_fetch_assoc($result);
        return $row;
    } else {
        $row = null;
        return $row;
    }
}
?>